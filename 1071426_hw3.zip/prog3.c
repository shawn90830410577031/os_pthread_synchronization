#include<stdio.h>
#include<string.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>
#include<time.h>
#include <ctype.h>

void* shot(void*);//每個thread要做的事
void* robot(void*);

pthread_mutex_t office_lock, hallway_lock, seat_lock[3];//hallway_lock--->先拿到hallway_lock才能進入cs
pthread_t *tid, robot_tid;
int *student_ID, n, waiting_count = 0, shot_count = 0;//waiting_count--->紀錄在走廊上等待人數(坐在椅子上的人數)

int main(int argc, char** argv){
    if(argc != 3){//命令列輸入超過3次
        printf("Argument error\n");
        exit(1);
    }
    else if(!isdigit(*argv[1]) || !isdigit(*argv[2])){//n(10-20) Seed(<100)
        printf("Invalid argument\n");
        exit(1);
    }
    n = strtoul(argv[1], NULL, 10);
    unsigned seed = strtoul(argv[2], NULL, 10);
    if(n < 10 || n > 20 || seed > 100){
        printf("Invalid argument\n");
        exit(1);
    }
    srand(seed);//設定亂數種子

    pthread_mutex_init(&office_lock, NULL);
    pthread_mutex_init(&hallway_lock, NULL);
    for(int i = 0; i < 3; i++)
        pthread_mutex_init(&seat_lock[i], NULL);

    tid = (pthread_t*)malloc(sizeof(pthread_t) * n);
    student_ID = (int*)malloc(sizeof(int) * n);

    pthread_create(&robot_tid, NULL, robot, NULL);
    for(int i = 0; i < n; i++){
        student_ID[i] = i + 1;
        pthread_create(&tid[i], NULL, shot, (void*)&student_ID[i]);
    }
    
    for(int i = 0; i < n; i++)
        pthread_join(tid[i], NULL);
    pthread_join(robot_tid, NULL);

    pthread_mutex_destroy(&office_lock);
    pthread_mutex_destroy(&hallway_lock);
    for(int i = 0; i < 3; i++)
        pthread_mutex_destroy(&seat_lock[i]);
    
    free(tid);
    free(student_ID);

    return 0;
}

void* shot(void *arg){
    int *id = (int*)arg;
    int shot_left = 3;
    time_t t;
    struct tm *info;//time.h 宣告struct tn 指標取的時分秒
    sleep(random() % 11);
    while(shot_left){//shot_left---->剩餘施打次數
        pthread_mutex_lock(&hallway_lock);//拿到可看等待人數key
        int seat_idx;
        if(waiting_count == 3){//waiting_count--->紀錄在走廊上等待人數(坐在椅子上的人數)
            pthread_mutex_unlock(&hallway_lock);
            sleep(random() % 6 + 5);//沒有位置讓thread再等待5-10分鐘 再回來看hallway_lock
            continue;
        }
        else{//等待人數<3 不用等待
            if(!waiting_count && !pthread_mutex_trylock(&office_lock)){//!waiting_count---->走廊上等待人數為0  _mutex_trylock(&office_lock)----->進辦公室的key   (-----> 可以進辦公室)
                time(&t), info = localtime(&t);
                printf("%02d:%02d:%02d Student%02d: Entering to get a shot\n", info->tm_hour, info->tm_min, info->tm_sec, *id);
                pthread_mutex_unlock(&hallway_lock);//
                sleep(2);//打疫苗等待2sec
                shot_left--;//扣掉剩餘施打疫苗次數
                shot_count++;
                time(&t), info = localtime(&t);
                printf("%02d:%02d:%02d Student%02d: Leaving to write YZU CS305 programs\n", info->tm_hour, info->tm_min, info->tm_sec, *id);
                pthread_mutex_unlock(&office_lock);
                sleep(random() % 21 + 10);
                continue;
            }
            else{//辦公室有人 且 有椅子可以坐
                seat_idx = waiting_count++;//waiting_count--->直接坐在waiting_count值得椅子
                pthread_mutex_lock(&seat_lock[seat_idx]);//seat_lock---->FCFS機制,搶椅子的鎖,代表此椅子不為空
                time(&t), info = localtime(&t);//
                printf("%02d:%02d:%02d Student%02d: Sitting #%d\n", info->tm_hour, info->tm_min, info->tm_sec, *id, seat_idx + 1);//坐位置的時間 info->tm_hour:時 info->tm_hour:時 info->tm_hour:時
                pthread_mutex_unlock(&hallway_lock);//丟出hallway_lock--->可以讓thread去改寫
            }
        }

        while(seat_idx){//seat_idx---->現在坐的位置(1號椅子)
            pthread_mutex_lock(&seat_lock[seat_idx - 1]);//要搶的前一個位置的lock
            pthread_mutex_unlock(&seat_lock[seat_idx--]);//可以放掉現在的lock
        }

        pthread_mutex_lock(&office_lock);
        time(&t), info = localtime(&t);
        printf("%02d:%02d:%02d Student%02d: Entering to get a shot\n", info->tm_hour, info->tm_min, info->tm_sec, *id);
        pthread_mutex_unlock(&seat_lock[0]);//一號椅子空出來
        pthread_mutex_lock(&hallway_lock);//
        waiting_count--;//從座位上移到辦公室
        pthread_mutex_unlock(&hallway_lock);
        sleep(2);//打疫苗2秒
        shot_count++;
        shot_left--;
        time(&t), info = localtime(&t);
        printf("%02d:%02d:%02d Student%02d: Leaving to write YZU CS305 programs\n", info->tm_hour, info->tm_min, info->tm_sec, *id);
        pthread_mutex_unlock(&office_lock);
        sleep(random() % 21 + 10);//打完一次疫苗要再等10-30秒時間間隔再去打疫苗
    }

    pthread_exit(NULL);
    return NULL;
}

void* robot(void *arg){
    int over = 0, last_shot_count = -1;//last_shout_count --->所有人打的次數
    time_t t;
    struct tm *info;
    while(!over){
        if(!pthread_mutex_trylock(&hallway_lock)){
            if(!waiting_count && !pthread_mutex_trylock(&office_lock)){//走廊上沒人 且 辦公室沒人
                if(shot_count == n * 3)//所有學生都打完
                    over = 1;//大家都打完
                else if(shot_count != last_shot_count){
                    time(&t), info = localtime(&t);
                    printf("%02d:%02d:%02d Robot: Sleep\n", info->tm_hour, info->tm_min, info->tm_sec);
                    last_shot_count = shot_count;
                }
                pthread_mutex_unlock(&office_lock);
            }
            pthread_mutex_unlock(&hallway_lock);
        }
    }
    time(&t), info = localtime(&t);
    printf("%02d:%02d:%02d Robot: All %d students receive vaccines.\n", info->tm_hour, info->tm_min, info->tm_sec, n);

    pthread_exit(NULL);
    return NULL;
}